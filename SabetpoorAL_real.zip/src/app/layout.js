import './globals.css'

export const metadata = {
  title: "Sabetpoor AL",
  description: "Stone Analyzer - Luxury Edition"
};

export default function RootLayout({ children }) {
  return (
    <html lang="fa" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
