"use client";
import { useState } from "react";
import HeaderLogo from "../components/HeaderLogo";
import FloatingButton from "../components/FloatingButton";
import UploadBox from "../components/UploadBox";
import StoneAnalyzer from "../components/StoneAnalyzer";
import { analyzeStone } from "../lib/deepseek";

export default function Home() {
  const [result, setResult] = useState(null);

  const handleUpload = (file) => {
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result;
      const data = await analyzeStone(base64);
      setResult(data);
    };
    reader.readAsDataURL(file);
  };

  return (
    <>
      <HeaderLogo />
      <div className="container">
        <UploadBox onImage={handleUpload} />
        <StoneAnalyzer data={result} />
      </div>
      <FloatingButton />
    </>
  );
}
