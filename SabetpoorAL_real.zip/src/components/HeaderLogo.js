export default function HeaderLogo() {
  return (
    <div style={{
      position: "fixed",
      top: 18,
      right: 18,
      color: "var(--turquoise)",
      fontSize: 18,
      fontWeight: "700",
      textShadow: "0 0 8px rgba(30,211,197,0.6)"
    }}>
      Sabetpoor AL
    </div>
  );
}
