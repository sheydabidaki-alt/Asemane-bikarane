export default function StoneAnalyzer({ data }) {
  if(!data) return null;
  return (
    <div className="glass" style={{ marginTop:20 }}>
      <h2>نتیجه تحلیل سنگ</h2>
      <p><strong>نوع:</strong> {data.type}</p>
      <p><strong>احتمال شهاب‌سنگ:</strong> {data.meteoriteChance}</p>
      <p><strong>چگالی:</strong> {data.density}</p>
      <p><strong>ارزش جهانی:</strong> {data.value}</p>
      <h3>{data.final}</h3>
    </div>
  );
}
