export default function UploadBox({ onImage }) {
  return (
    <div className="glass center" style={{ flexDirection: "column", gap:12 }}>
      <h3>آپلود عکس سنگ</h3>
      <input type="file" accept="image/*" onChange={(e)=> onImage(e.target.files[0])} />
    </div>
  );
}
