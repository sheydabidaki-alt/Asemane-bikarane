export default function FloatingButton({ onClick }) {
  return (
    <div
      onClick={onClick}
      style={{
        position: "fixed",
        bottom: 28,
        right: 28,
        width: 64,
        height: 64,
        borderRadius: "50%",
        background: "rgba(255,255,255,0.06)",
        backdropFilter: "blur(8px)",
        border: "2px solid rgba(30,211,197,0.5)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontSize: 26,
        color: "white",
        cursor: "pointer"
      }}
    >
      ⚡
    </div>
  );
}
